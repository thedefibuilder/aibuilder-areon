const hre = require("hardhat");

async function main() {
  const contractName = "LagrangePlatform";

  const constructorArgs = ["<ADD_ARGS_HERE>"]


  const ContractFactory = await hre.ethers.getContractFactory(contractName);
  const contract = await ContractFactory.deploy(...constructorArgs);

  await contract.deployed();

  console.log(`🧑‍🍳 ${contractName} has been deployed to ${contract.address}!`);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
