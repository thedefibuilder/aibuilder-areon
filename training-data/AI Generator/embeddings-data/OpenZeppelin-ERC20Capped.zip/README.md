# Cookbook.dev

## Find any smart contract, build your project faster

Get ready-to-use Hardhat projects directly from https://www.cookbook.dev

## Please follow these 4 steps for a local deploy

<p>
  <strong> Step 1: Install</strong>
  Please run "npm i " to install dependencies in package.json
</p>

<p>
  <strong> Step 2: Compile</strong>
  Please run npm run compile to compile your contracts.
</p>

<p>
  <strong> Step 3: Add arguments</strong>
  Please add arguments to the constructorArgs array in the deploy.js file and save.  If you do not need any arguments please leave the array empty.
</p>

<p>
  <strong> Step 4: Deploy</strong>
  Please run npm run deploy to compile your contracts.
</p>

## Please follow these steps for a testnet deploy

<p>
  <strong> Step 1: Install</strong>
  Please run "npm i " to install dependencies in package.json
</p>

<p>
  <strong> Step 2: Fill out your .env file</strong>
    Please fill out your .env file with your infura key of your chosen testnet and your private key.  Afterward change the name of the file to .env and create a gitignore to ignore your .env file.
</p>

<p>
  <strong> Step 3: Compile your Contracts</strong>
  please run npx hardhat compile in your terminal to compile your contracts.
</p>
<p>
  <strong> Step 4: Deploy to a testnet using an rpc</strong>
  please run "npx hardhat run --network (your-network) scripts/deploy.js" in your terminal if you are using a testnet. Please replace NAME_OF_NETWORK with the name of the testnet you are using by it's name in the hardhat.config.js file.

</p>

Example Contracts and Projects

- [Simple Token](https://www.cookbook.dev/contracts/simple-token)
- [Azuki EFC721A NFT](https://www.cookbook.dev/contracts/Azuki-ERC721A-NFT-Sale)
- [Uniswap Labs](https://www.cookbook.dev/profiles/Uniswap-Labs)

[Search for 100s of other contracts](https://www.cookbook.dev/search?q=&categories=Contracts&sort=popular&filter=&page=1)
